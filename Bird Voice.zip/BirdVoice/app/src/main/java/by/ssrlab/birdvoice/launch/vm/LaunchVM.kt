package by.ssrlab.birdvoice.launch.vm

import androidx.lifecycle.ViewModel

class LaunchVM: ViewModel() {
}