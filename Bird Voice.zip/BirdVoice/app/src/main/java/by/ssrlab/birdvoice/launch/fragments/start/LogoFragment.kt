package by.ssrlab.birdvoice.launch.fragments.start

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import by.ssrlab.birdvoice.R
import by.ssrlab.birdvoice.databinding.FragmentLogoBinding
import by.ssrlab.birdvoice.launch.LaunchActivity

class LogoFragment: Fragment() {

    private lateinit var binding: FragmentLogoBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentLogoBinding.inflate(layoutInflater)

        animatorSetup()
        (activity as LaunchActivity).hideStatusBar()

        return binding.root
    }

    private fun animatorSetup(){
        binding.logoAnimator.startAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.logo_slide_out_right))
        binding.logoAnimator.visibility = View.INVISIBLE
    }
}